# DevOps Jump Start
XPeppers DevOps jump start basic workshop starting repo

More info: http://www.xpeppers.com/formazione-devops-continuous-integration
