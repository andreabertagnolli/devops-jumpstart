set :rack_env, 'test'

role :app, ["vagrant@testing"]
