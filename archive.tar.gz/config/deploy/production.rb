set :rack_env, 'production'

role :app, ["vagrant@production"]
