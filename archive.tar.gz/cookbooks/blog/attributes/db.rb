node.default['blog']['database']['name'] = 'blog'
node.default['blog']['database']['username'] = 'blog'
node.default['blog']['database']['password'] = 'blog'
