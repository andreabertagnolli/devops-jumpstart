include_recipe 'blog::web'
include_recipe 'blog::ruby'
include_recipe 'blog::db'
