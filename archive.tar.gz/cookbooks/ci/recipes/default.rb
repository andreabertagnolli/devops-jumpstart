include_recipe 'ci::jenkins'
include_recipe 'ci::ssh'
