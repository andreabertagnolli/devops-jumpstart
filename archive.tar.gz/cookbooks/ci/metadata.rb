name 'ci'
description 'Installs/Configures continuous integration server'
version '0.1.0'
supports 'ubuntu', '>= 14.04'

depends 'apt'
depends 'jenkins'
